# RemoteOK Jobs Scraping & Analysis Project

A comprehensive data pipeline project that scrapes remote job listings from RemoteOK, cleans the data, and generates visualizations and insights.

## 📋 Project Overview

This project implements an end-to-end data workflow:
1. **Scrape** remote job data from RemoteOK's JSON feed
2. **Clean** and normalize the data
3. **Analyze** and visualize job market trends

The project uses Jupyter notebooks for each stage, making it easy to explore data and understand the workflow.

## 📁 Project Structure

```
remoteok-scraping-project/
├── README.md                             # This file
├── requirements.txt                      # Python dependencies
├── src/
│   ├── scraper.py                        # Web scraping script
│   ├── data_cleaner.py                   # Data cleaning script
│   └── analyzer.py                       # Data analysis & visualizations
├── data/
│   ├── raw/
│   │   └── remoteok_raw.csv              # Raw scraped data
│   └── cleaned/
│       └── remoteok_jobs_cleaned.csv     # Processed and cleaned data
├── visualizations/
│   ├── top_skills.png                    # Top skills chart
│   ├── job_type_distribution.png         # Job type distribution pie chart
│   ├── top_job_titles.png                # Most common job titles
│   └── skill_frequency_comparison.png    # Skill frequency analysis
└── reports/
    ├── analysis_report.pdf               # Detailed analysis report
    └── methodology.md                    # Project methodology
```

## 🚀 Workflow

### 1. Data Scraping (`scraper.ipynb`)
- Fetches job data from RemoteOK's JSON API endpoint
- Extracts relevant fields: job title, company, tags, location, job type, and URL
- Saves raw data to CSV for processing

**Key Features:**
- User-Agent headers to avoid blocking
- Extracts job tags/skills
- Reconstructs full job URLs
- Logs job count statistics

### 2. Data Cleaning (`data_cleaner.ipynb`)
- Loads raw CSV data
- Infers job types from metadata and tags
- Removes duplicates based on title, company, and URL
- Normalizes text fields (trimming, title case)
- Standardizes location data (handles missing values)
- Exports cleaned data

**Data Transformations:**
- Job type inference using keyword matching
- Duplicate removal to ensure data quality
- Text normalization and standardization
- Missing value handling

### 3. Data Analysis (`analyzer.ipynb`)
- Loads cleaned dataset
- Generates visualizations including:
  - Job type distribution (pie chart)
  - Additional insights and trends
- Exports charts to `visualizations/` folder

## 📊 Data Columns

### Raw Data (`remoteok_raw.csv`)
| Column | Description |
|--------|-------------|
| Job Title | Position title |
| Company Name | Employer name |
| Job Tags / Skills | Required skills/tags |
| Location | Job location |
| Job Type (Raw) | Raw job type from source |
| Epoch | Timestamp |
| Job URL | Link to job posting |

### Cleaned Data (`remoteok_jobs_cleaned.csv`)
| Column | Description |
|--------|-------------|
| Job Title | Cleaned position title |
| Company Name | Cleaned employer name |
| Job Tags / Skills | Standardized skills/tags |
| Location | Standardized location |
| Job Type | Inferred and normalized job type |
| Epoch | Timestamp |
| Job URL | Job posting link |

## 🔧 Requirements

- Python 3.7+
- pandas
- requests
- matplotlib

## 📦 Installation

1. Clone or download this project
2. Install required packages:
```bash
pip install pandas requests matplotlib
```

## 🏃 Running the Project

### Step 1: Scrape Data
Open and run `scraper.ipynb` to fetch the latest jobs from RemoteOK:
```
python src/scraper.ipynb
```

### Step 2: Clean Data
Open and run `data_cleaner.ipynb` to process the raw data:
```
python src/data_cleaner.ipynb
```

### Step 3: Analyze Data
Open and run `analyzer.ipynb` to generate visualizations:
```
python src/analyzer.ipynb
```

**Note:** Each notebook is self-contained and can be run independently (provided dependencies exist).

## 📈 Key Insights

The analysis provides insights into:
- Distribution of job types (Full-Time, Contract, Freelance, etc.)
- Geographic distribution of remote jobs
- In-demand skills and technologies
- Job market trends

## 🔄 Data Flow

```
RemoteOK API
    ↓
    Scraper (raw CSV) 
    ↓
    Data Cleaner (cleaned CSV)
    ↓
    Analyzer (visualizations & reports)
```

## 💡 Job Type Classification

The project automatically categorizes jobs into:
- Full-Time
- Contract
- Part-Time
- Freelance
- Internship
- Temporary
- Not Specified (default)

Classification is based on explicit type data or inferred from job tags.

## 📝 Notes

- The RemoteOK API endpoint: `https://remoteok.com/remote-jobs.json`
- Duplicates are identified by: Job Title + Company Name + Job URL
- Location "Worldwide" is assigned to jobs without specific location data
- All timestamps are stored in Unix Epoch format

## 🛠️ Customization

You can customize:
- Job type keywords in `data_cleaner.ipynb`
- Visualization styles in `analyzer.ipynb`
- API headers and URLs in `scraper.ipynb`

## 📧 Support & Issues

For issues or questions about the project, review the individual notebooks for detailed comments and documentation.

## 📄 License

This project is for educational and research purposes.

---

**Last Updated:** January 2026
